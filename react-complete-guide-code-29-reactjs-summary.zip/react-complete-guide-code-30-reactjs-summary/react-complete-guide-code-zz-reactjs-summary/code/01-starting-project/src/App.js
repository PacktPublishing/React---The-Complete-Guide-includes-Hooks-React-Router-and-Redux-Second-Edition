function App() {
  return <div>Hello!</div>;
}

export default App;
