// our-domain.com/

function HomePage() {
  return <h1>The Home Page</h1>
}

export default HomePage;