function WelcomePage() {
  return (
    <main>
      <h1>Welcome Page</h1>
      <p>Learn more about React Router 6.4</p>
    </main>
  );
}

export default WelcomePage;
