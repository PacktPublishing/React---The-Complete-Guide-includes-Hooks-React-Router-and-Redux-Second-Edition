import BasicForm from './components/BasicForm';

function App() {
  return (
    <div className="app">
      <BasicForm />
    </div>
  );
}

export default App;
