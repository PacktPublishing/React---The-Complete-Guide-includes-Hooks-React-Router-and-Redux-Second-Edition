const NewQuote = () => {
  return <h1>New Quote Page</h1>
};

export default NewQuote;