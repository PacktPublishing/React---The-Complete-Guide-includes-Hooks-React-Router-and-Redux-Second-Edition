import React from 'react';

import Ingredients from './components/Ingredients/Ingredients';

const App = props => {
  return <Ingredients />;
};

export default App;
